import Myprojects from "@components/Projects/MyProjects";

const HomePage = () => {
  return (
    <>
      <Myprojects />
    </>
  );
};

export default HomePage;
